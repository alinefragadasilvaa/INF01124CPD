import utils
import sorts
import time

def teste(entrada, saida, particionador, particionamento):
    vetores = utils.leEntrada(entrada)

    for vetor in vetores:
        tamanho, vetor = utils.montaVetor(vetor)

       # ordenar vetor
       # imprimir saida

# teste com a mediana de 3 e lomuto
teste('Inputs/entrada-quicksort.txt', 'Outputs/stats-mediana-lomuto.txt', sorts.mediana, sorts.lomuto) 

# teste com a mediana de 3 e hoare
teste('Inputs/entrada-quicksort.txt', 'Outputs/stats-mediana-hoare.txt', sorts.mediana, sorts.hoare) 

# teste com número aleatorio e lomuto
teste('Inputs/entrada-quicksort.txt', 'Outputs/stats-aleatorio-lomuto.txt', sorts.randomizado, sorts.lomuto) 

# teste com número aleatorio e hoare
teste('Inputs/entrada-quicksort.txt', 'Outputs/stats-aleatorio-hoare.txt', sorts.randomizado, sorts.hoare) 

