import utils
import math

# insertion sort
def insertionSort(vetor, tamanho, deslocamento, inicio):
    for i in range(inicio+deslocamento, tamanho, deslocamento):
        chave = vetor[i]
        j = i-deslocamento
        while j>=0 and vetor[j]>chave:
            vetor[j+deslocamento] = vetor[j]
            j = j-deslocamento
        vetor[j+deslocamento] = chave
    return vetor

# shell sort 
def shellSort(vetor, tamanho, indice, sequencia, acompanhar, saida = None):
    while indice >= 0:
        for inicio in range(sequencia[indice]):
            vetor = insertionSort(vetor, tamanho, sequencia[indice], inicio)
        
        # imprime vetor ordenado parcialmente
        if(acompanhar):
            linha = ' '.join(list(map(str, vetor)))
            utils.escreveSaida(saida, linha + ' INCR=' + str(sequencia[indice]) + '\n')

        indice=indice-1
    return vetor

# contantes para as sequências do shell sort
shell = 0
knuth = 1
ciura = 2

# retorna a sequência escolhida para deslocamento do shell sort
def defineSequencia(id):
    if(id==shell):
        return [1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576]
    if(id==knuth):
        return [1,4,13,40,121,364,1093,3280,9841,29524,88573,265720,797161,2391484]
    if(id==ciura):
        return [1,4,10,23,57,132,301,701,1577,3548,7983,17961,40412,90927,204585,460316,1035711]

# recebe a constante da sequência e retorna seu nome 
def nomeSequencia(id):
    if(id==shell):
        return 'SHELL'
    if(id==knuth):
        return 'KNUTH'
    if(id==ciura):
        return 'CIURA'

# retorna o índice da sequência do primeiro deslocamento do shell sort
def primeiroDeslocamento(sequencia,tamanho):
    i = 0
    for deslocamento in sequencia:
        if deslocamento >= tamanho:
            return i-1
        i=i+1

global trocas # incluir trocas do particionador
global chamadasRecursivas

# quick sort
def quickSort(vetor, inicio, fim):
    if f>i:
        # particionador = particiona(vetor, inicio, fim)
        chamadasRecursivas += 2
        quickSort(vetor, inicio, particionador-1)
        quickSort(vetor, particionador+1, fim)

# exemplo: 
# 7, 50, 5, 12, 20, 11, 10
# 0   1  2   3   4   5   6
# randomizado sorteia um indice aleatorio e troca o elemento desse incide com o primeiro elemento do vetor
# mediana de tres calcula a media entre o primeiro o ultimo e o do meio (7, 12 e 10) e troca a mediana com o primeiro elemento do vetor

randomizado = 0
mediana = 1

#define particionador
def defineParticionador(id, vetor=None, inicio=None, fim=None):
    if id == randomizado:
        return randint(inicio, fim)
    if id == mediana:
        return medianaDeTres(vetor, inicio, fim)

# calcula a mediana de trÊs do vetor
def medianaDeTres(vetor, inicio, fim):
        elementos[0] = vetor[inicio]
        elementos[1] = vetor[fim]
        elementos[2] = vetor[math.floor((inicio+fim)/2)]
        elementos = insertionSort(elementos, 3, 1, 1)
        return elementos[1]

lomuto = 0
hoare = 1

# define particionamento
def defineParticionamento(id, vetor, inicio, fim):
    if id == lomuto:
        return lomuto(vetor, inicio, fim)
    if id == hoare:
        return hoare(vetor, inicio, fim)

# particionamento lomuto
def lomuto(vetor, inicio, fim):
    chave = vetor[inicio] # particionador
    index = inicio + 1
    for i in range(inicio + 1, fim+1):
        if vetor[i]<chave:
            trocas += 1
            vetor[i], vetor[index] = vetor[index], vetor[i] # swap
            index=index+1
    trocas += 1
    vetor[inicio], vetor[index+1] = vetor[index+1], vetor[inicio] # swap
    return index-1

# particionamento hoare
def hoare(vetor, inicio, fim):
    chave = vetor[inicio] # particionador
    i = inicio, j = fim+1
    while(True):
        while vetor[i+=1] <= chave: # verificar se os indices estão corretos
            if i == fim:
                break
        while chave < vetor[j-=1]:
            if i == inicio:
                break
        if i >= j:
            break
        trocas += 1
        vetor[i], vetor[j] = vetor[j], vetor[i] # swap
    trocas += 1
    vetor[inicio], vetor[j] = vetor[j], vetor[inicio] # swap
    return j

